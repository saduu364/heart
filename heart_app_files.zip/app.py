import streamlit as st
import pandas as pd
import joblib
import numpy as np

# Load trained model
model = joblib.load("heart_attack_model.pkl")

# Page title
st.set_page_config(page_title="Heart Attack Risk Predictor")
st.title("💓 Heart Attack Risk Prediction App")
st.markdown("Enter patient's details below to assess the risk of heart attack.")

# Input form
with st.form("heart_form"):
    age = st.slider("Age", 20, 100, 50)
    sex = st.selectbox("Sex", [0, 1], format_func=lambda x: "Female" if x == 0 else "Male")
    cp = st.selectbox("Chest Pain Type", [0, 1, 2, 3], format_func=lambda x: {
        0: "Typical Angina", 1: "Atypical Angina", 2: "Non-anginal Pain", 3: "Asymptomatic"
    }[x])
    trestbps = st.slider("Systolic Blood Pressure", 80, 200, 120)
    chol = st.slider("Cholesterol (mg/dL)", 100, 500, 200)
    fbs = st.selectbox("Fasting Blood Sugar > 120 mg/dL", [0, 1])
    restecg = st.selectbox("Resting ECG", [0, 1, 2])
    thalachh = st.slider("Maximum Heart Rate", 60, 220, 150)
    exang = st.selectbox("Exercise-induced Angina", [0, 1])
    oldpeak = st.slider("ST Depression", 0.0, 6.0, 1.0)
    slope = st.selectbox("Slope of Peak ST Segment", [0, 1, 2])
    ca = st.slider("Number of Major Vessels (0–3)", 0, 3)
    thal = st.selectbox("Thalassemia", [1, 2, 3], format_func=lambda x: {
        1: "Fixed Defect", 2: "Normal", 3: "Reversible Defect"
    }[x])

    submitted = st.form_submit_button("Predict")

if submitted:
    input_data = np.array([[thal, cp, thalachh, chol, oldpeak, age, ca, sex,
                            slope, restecg, fbs, trestbps]])
    prediction = model.predict(input_data)[0]
    prob = model.predict_proba(input_data)[0][1]

    st.markdown("---")
    if prediction == 1:
        st.error(f"❗ High Risk of Heart Attack! ({prob:.2%} probability)")
    else:
        st.success(f"✅ Low Risk of Heart Attack. ({prob:.2%} probability)")