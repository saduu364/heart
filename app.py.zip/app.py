
import streamlit as st
import pandas as pd
import numpy as np
import pickle

st.set_page_config(page_title="Heart Attack Prediction App", layout="wide")

st.title("❤️ Heart Attack Risk Prediction")
st.markdown("Upload patient data to predict risk using a trained MLP model.")

uploaded_file = st.file_uploader("📤 Upload CSV File", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)
    st.success(f"✅ Uploaded file: {uploaded_file.name}")
    st.dataframe(df.head())

    try:
        with open("heart_attack_model.pkl", "rb") as file:
            model = pickle.load(file)
        X = df.drop(columns=["PatientID"], errors="ignore")
        prediction = model.predict(X)
        proba = model.predict_proba(X)
        df['Predicted Risk'] = prediction
        df['Probability Low'] = proba[:, 0]
        df['Probability High'] = proba[:, 1]

        st.subheader("📋 Prediction Results")
        st.dataframe(df)
        csv = df.to_csv(index=False).encode('utf-8')
        st.download_button("⬇️ Download Results as CSV", csv, "prediction_results.csv", "text/csv")

    except Exception as e:
        st.error("❌ Error loading model or predicting. Ensure 'heart_attack_model.pkl' is in the app directory.")
        st.exception(e)
